<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "helloworld";

// Connect to the database
$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch data from a table (e.g., 'testing')
$sql = "SELECT ID, message FROM testing";
$result = mysqli_query($conn, $sql);

$data = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

// Return data as JSON
echo json_encode($data);

mysqli_close($conn);
?>
