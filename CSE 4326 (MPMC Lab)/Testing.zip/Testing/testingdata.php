<?php
  $hostname="localhost";
  $username="root";
  $password="";
  $database="helloworld";

  $conn = mysqli_connect($hostname, $username, $password, $database);

  if(!$conn) {
    die("Conection failed: " .mysqli_connect_error());
  }
  echo "Database connection is OK <br>";
  if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["ID"])) {
    $id = intval($_POST["ID"]);
    $message = "Hello world";

    $sql = "INSERT INTO testing (ID, message) VALUES ($id, '$message')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  }
  echo "hello world";
?>