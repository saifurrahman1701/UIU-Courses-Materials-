#include<iostream>
#include<vector>
using namespace std;

int main() {
    int n, W;
    cin>>n>>W;
    vector<pair<int, int>> items(n);
    /// 2d-array using vector
    vector<vector<int>> DP(W+1, vector<int> (n+1));

    /// items->first = weight, items->second = value
    for(int i=0;i<n;i++) {
        cin>>items[i].first>>items[i].second;
    }

    for(int i=0;i<=n;i++) {
      DP[0][i] = 0;
    }

    for(int w=0;w<=W;w++) {
      DP[w][n] = 0;
    }

    for(int w = 1;w<=W;w++) {
      for(int i=n-1;i>=0;i--) {
        int not_taking = DP[w][i+1];
        int taking = 0;
        if(w-items[i].first >=0) {
          taking = DP[w-items[i].first][i+1] + items[i].second;
        }
        int ans = max(taking, not_taking);
        DP[w][i] = ans;
      }
    }

    cout<<DP[W][0]<<endl;

    return 0;
}
