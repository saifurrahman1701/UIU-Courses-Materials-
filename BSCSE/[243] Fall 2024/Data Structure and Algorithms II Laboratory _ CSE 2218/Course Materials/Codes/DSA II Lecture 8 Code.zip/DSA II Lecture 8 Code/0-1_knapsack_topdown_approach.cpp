#include<iostream>
#include<vector>
using namespace std;

int compute_ans(int W, int i, int n, vector<pair<int, int>> &items, vector<vector<int>> &DP) {
    /// base case
    if(i == n) {
        return 0;
    }
    if(DP[W][i] != -1) {
        return DP[W][i];
    }
    /// recursive function
    int not_taking = compute_ans(W, i+1, n, items, DP);

    int taking = 0;
    if(W-items[i].first >= 0) {
        taking = compute_ans(W-items[i].first, i+1, n, items, DP) + items[i].second;
    }
    int ans = max(not_taking, taking);
    DP[W][i] = ans;
    return ans;
}

int main() {
    int n, W;
    cin>>n>>W;
    vector<pair<int, int>> items(n);
    /// 2d-array using vector
    vector<vector<int>> DP(W+1, vector<int> (n+1, -1));

    /// items->first = weight, items->second = value
    for(int i=0;i<n;i++) {
        cin>>items[i].first>>items[i].second;
    }

    int ans = compute_ans(W, 0, n, items, DP);
    cout<<ans<<endl;

    for(int i=0;i<=W;i++) {
        for(int j=0;j<=n;j++) {
            cout<<DP[i][j]<<" ";
        }
        cout<<endl;
    }
}
