#include<iostream>
#include<vector>
using namespace std;
 
int sol(int sum, vector<int> &nums, vector<int> &DP) {
    ///base case
    if(sum == 0) {return 1;}
    if(sum < 0) {return 0;}
    if(DP[sum] != -1) {
        return DP[sum];
    }
    ///recursive solution
    int ans = 0;
    for(auto it: nums) {
        int new_sum = sum - it;
        ans += sol(new_sum, nums, DP);
    }
    DP[sum] = ans;
    return ans;
}
 
int main() {
    int n, sum;cin>>n>>sum;
    vector<int> nums(n), DP(sum+1, -1);
    for(int i=0;i<n;i++) {
        cin>>nums[i];
    }
    int ans = sol(sum, nums, DP);
    cout<<ans<<endl;
}