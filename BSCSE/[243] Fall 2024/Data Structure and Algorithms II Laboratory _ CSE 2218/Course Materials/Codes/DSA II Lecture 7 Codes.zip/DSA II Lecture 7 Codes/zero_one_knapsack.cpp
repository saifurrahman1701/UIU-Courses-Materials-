#include<iostream>
#include<vector>
using namespace std;

int dp(vector<pair<int, int>> items, int n, int w, int i) {
    cout<<w<<" "<<i<<endl;
    if(i == n) {
        return 0;
    }
    if(w <= 0) {
        return 0;
    }

    int max_profit = 0;
    if(i != 0) max_profit = items[i-1].second;

    for(int j=i;j<n;j++) {
        /// if we take
        int profit1 = dp(items, n, w-items[j].first, j+1);

        /// if we do not take
        int profit2 = dp(items, n, w, j+1);
        cout<<"x "<<profit1<<" "<<profit2<<endl;
        max_profit += max(profit1, profit2);
    }
    cout<<max_profit<<endl;
    return max_profit;
}

int main() {
    int n, w;
    cin>>n>>w;
    vector<pair<int, int>> items;
    /// items[i].first = weight, items[i].second = value
    for(int i=0;i<n;i++) {
        int weight, value;
        cin>>weight>>value;
        items.push_back({weight, value});
    }

    int profit = dp(items, n, w, 0);

    cout<<profit<<endl;
}
