// Top-down DP

// O(n) time complexity
// O(n) space complexity

#include<iostream>
#include<vector>
using namespace std;

long long fib(int n, vector<long long> &Storage) {
    if(n == 0) return 0;
    if(n == 1) return 1;

    if(Storage[n] != 0) {
        return Storage[n];
    }

    long long fib_n = fib(n-1, Storage) + fib(n-2, Storage);
    Storage[n] = fib_n;
    return fib_n;
}

int main() {
    int n;
    cin>>n;
    vector<long long> Storage(n+1);
    long long ans = fib(n, Storage);

    cout<<ans<<endl;
}
