// Bottom-up DP

// O(n) time complexity
// O(n) space complexity

#include<iostream>
#include<vector>
using namespace std;

#define ll long long


int main() {
    ll n;cin>>n;

    vector<ll> Storage(n+1); // O(n)

    Storage[0] = 0;
    Storage[1] = 1;

    for(int i=2; i<=n; i++) { // O(n)
        Storage[i] = Storage[i-1] + Storage[i-2]; // O(1)
    }

    cout<<Storage[n]<<endl;
}
