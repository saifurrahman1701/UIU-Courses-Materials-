#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {

    vector<int> vec;
    // 1, 2, 3, 4, 5

    vec.push_back(1);
    vec.push_back(2);
    vec.push_back(4);
    vec.push_back(5);
    vec.push_back(5);
    vec.push_back(6);

//    for(int i=0;i<5;i++) {
//        cout<<vec[i]<<" ";
//    }
//    cout<<endl;

    vector<int>::iterator it;

    for(it = vec.begin(); it != vec.end(); it++) {
        cout<<*it<<" ";
    }
    cout<<endl;

    vector<int>::iterator it1;
    it1 = lower_bound(vec.begin(), vec.end(), 3);

    int idx1 = it1 - vec.begin();

    cout<<idx1<<endl;

    vector<int>::iterator it2;
    it2 = upper_bound(vec.begin(), vec.end(), 3);

    int idx2 = it2 - vec.begin();

    cout<<idx2<<endl;

    cout<<"Count "<<idx2 - idx1<<endl;






}
