#include<iostream>
#include<map>
#include<unordered_map>

using namespace std;

int main() {

//    map<int, int> mp;
    unordered_map<int, int> mp;

    /// insertion
    // 1
//    mp.insert(make_pair(-1, 2));
//    mp.insert(make_pair(1, 3));
//    mp.insert({2, 2});
//    mp.insert({3, 1});
//

    // 2
    int arr[] = {-1, 1, 4, 1, 2, 3, 7, 1, -1, 2};

    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<n<<endl;

    for(int i=0;i<n;i++) {
        mp[arr[i]]++;
    }

//    map<int, int>::iterator it;
    unordered_map<int, int>::iterator it;

    for(it = mp.begin(); it!= mp.end(); it++) {
        cout<<it->first<<" "<<it->second<<endl;
    }
}
