#include<iostream>
#include<set>
#include<unordered_set>

using namespace std;

int main() {

//    set<int> st;
    unordered_set<int> st;

    // 4 1 2 3 7 1 -1 2
    st.insert(4);
    st.insert(1);
    st.insert(2);
    st.insert(3);
    st.insert(7);
    st.insert(1);
    st.insert(-1);
    st.insert(2);

//    set<int>::iterator it;
    unordered_set<int>::iterator it;
    for(it = st.begin();it!= st.end();it++) {
        cout<<*it<<" ";
    }
    cout<<endl;
}
