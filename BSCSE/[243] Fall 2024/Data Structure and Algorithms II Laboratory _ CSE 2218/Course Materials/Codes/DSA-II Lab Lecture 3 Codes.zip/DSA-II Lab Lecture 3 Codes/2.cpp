#include<iostream>
#include<list>

using namespace std;

int main() {

    list<int> lst;

    // 1, 2, 3, 4, 5
    lst.push_back(1);
    lst.push_back(2);
    lst.push_back(3);
    lst.push_back(4);
    lst.push_back(5);

    list<int>::iterator it;

    for(it = lst.begin(); it!= lst.end(); it++) {
        cout<<*it<<" ";
    }
    cout<<endl;

    /// front
    cout<<lst.front()<<endl;

    /// back
    cout<<lst.back()<<endl;
}
