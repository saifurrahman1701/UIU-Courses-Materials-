#include<iostream>
using namespace std;

void FindCrossSum(int A[], int i, int j, int &CrossSum, int &CrossSum_LOW, int &CrossSum_HIGH) {
    int mid = (i+j)/2;

    int Left_sum = INT_MIN;
    int sum = 0;
    for(int k = mid; k>=i; k--) {
        sum += A[k];
        if(sum >= Left_sum) {
            CrossSum_LOW = k;
            Left_sum = sum;
        }
    }
    int Right_sum = INT_MIN;
    sum = 0;
    for(int k=mid+1;k<=j;k++) {
        sum+=A[k];
        if(sum >= Right_sum) {
            Right_sum = sum;
            CrossSum_HIGH = k;
        }
    }
    CrossSum = Left_sum + Right_sum;

}

void fun(int A[], int i, int j, int &sum, int &L, int &R) {
    if(i == j) {
        sum = A[i];
        L = i;
        R = i;
        return;
    }
    int mid = (i+j)/2;
    int Lsum = 0, Lsum_Low, Lsum_High;
    fun(A, i, mid, Lsum, Lsum_Low, Lsum_High);
    int Rsum = 0, Rsum_Low, Rsum_High;
    fun(A, mid+1, j, Rsum, Rsum_Low, Rsum_High);
    int CrossSum = 0, CrossSum_Low, CrossSum_HIGH;
    FindCrossSum(A, i, j, CrossSum, CrossSum_Low, CrossSum_HIGH);

    if(Lsum >= Rsum && Lsum >= CrossSum) {
        sum = Lsum;
        L = Lsum_Low;
        R = Lsum_High;
    }
    else if(Rsum >= Lsum && Rsum >= CrossSum) {
        sum = Rsum;
        L = Rsum_Low;
        R = Rsum_High;
    }
    else {
        sum = CrossSum;
        L = CrossSum_Low;
        R = CrossSum_HIGH;
    }
}

int main() {
    int A[] = {-16, -23, 18, 20, -7, 12, -5};
    int i = 0;
    int j = 6;
    int sum = 0;
    int L, R;
    fun(A, i, j, sum, L, R);
    cout<<sum<<endl;
}
