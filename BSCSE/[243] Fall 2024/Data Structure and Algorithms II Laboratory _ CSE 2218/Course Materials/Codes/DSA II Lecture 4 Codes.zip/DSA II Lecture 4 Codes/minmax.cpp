#include<iostream>
using namespace std;

void MaxMin(int A[], int i, int j, int &cnt) {
    if(i == j) {
        int num = A[i];
        if(num%2 == 0) {
            cnt++;
        }
        return;
    }
    int mid = (i+j)/2;
    MaxMin(A, i, mid, cnt);
    MaxMin(A, mid+1, j, cnt);
}

int main() {

    int A[] = {22, 13, -5, -8, 15, 60, 17, 31, 47};

    int i = 0;
    int j = 8;

    int cnt = 0;
    MaxMin(A, i, j, cnt);
    cout<<cnt<<endl;
}
