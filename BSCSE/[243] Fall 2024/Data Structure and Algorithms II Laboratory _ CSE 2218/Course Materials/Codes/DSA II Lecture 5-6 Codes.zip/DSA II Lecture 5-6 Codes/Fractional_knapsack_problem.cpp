#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
    int n, capacity;cin>>n>>capacity;

    /// pair.first = v/w && pair.second = w
    vector<pair<int, int>> Vec;

    for(int i=0;i<n;i++) {
        int w, v;
        cin>>w>>v;
        int per_unit_value = v/w;
        Vec.push_back({per_unit_value, w});
    }

    sort(Vec.begin(), Vec.end());
    for(auto it: Vec) {
        cout<<it.first<<" "<<it.second<<endl;
    }

    auto i = 1;
    auto j = 'a';
    auto k = "hello";
//    auto x = Vec.begin();
//    vector<pair<int, int>>::iterator it;
//    it = Vec.begin();

    int ans = 0;
    for(auto it = Vec.rbegin(); it!= Vec.rend(); it++) {
//        cout<<it->first<<" "<<it->second<<endl;
        int per_unit_value = it->first;
        int weight = it->second;

        if(capacity >= weight) {
            ans += (weight * per_unit_value);
            capacity = capacity - weight;
        }
        else {
            ans += (capacity * per_unit_value);
            capacity = 0;
            break;
        }
    }
    cout<<ans<<endl;
}
