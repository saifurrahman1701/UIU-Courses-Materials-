#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {

    /// Task 1: Input number of requests
    int n;
    cin>>n;
    ///O(1)
    /// Task 2: Input the requests

    /// p1.first = finsh time && p1.second = start time
    vector<pair<int, int>> Vec;

    for(int i=0;i<n;i++) {
        int s, f;
        cin>>s>>f;
        Vec.push_back({f, s});
    }
    /// O(n)

    /// sorting the activities
    sort(Vec.begin(), Vec.end());
    ///O(n logn)

    cout<<endl;
//    for(auto it: Vec) {
//        cout<<it.first<<" "<<it.second<<endl;
//    }

    /// pair.first = finish time
    /// pair.second = start time

    /// Main algorithm

    vector<pair<int, int>> ans;

    ans.push_back({Vec[0].first, Vec[0].second});

    int i = 0;

    for(int m = 1;m<n; m++) {
        if(Vec[m].second >= Vec[i].first) {
            ans.push_back({Vec[m].first, Vec[m].second});
            i = m;
        }
    }

    cout<<ans.size()<<endl;
    for(auto it: ans) {
        cout<<it.second<<" "<<it.first<<endl;
    }

    /// O(n)
}
