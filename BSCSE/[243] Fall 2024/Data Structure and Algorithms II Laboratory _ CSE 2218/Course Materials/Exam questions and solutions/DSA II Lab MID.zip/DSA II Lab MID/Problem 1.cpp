#include<iostream>
#include<set>
#include<vector>
using namespace std;

int main() {
    int n, m;cin>>n>>m;
    set<int> items;
    for(int i=0;i<n;i++) {
        int x;cin>>x;
        items.insert(x);
    }
    int num = 1;
    vector<int> ans;
    while(m>=num) {
        if(items.find(num) == items.end()) {
            ans.push_back(num);
            m -= num;
        }
        num++;
    }
    
    cout<<ans.size()<<endl;
    for(auto it: ans) cout<<it<<" ";
    
    return 0;
}