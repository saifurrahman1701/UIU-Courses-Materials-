#include<iostream>
#include<set>
#include<string>
using namespace std;

void countAlphabets(string &str, set<char> &characters, int i) {
    if(i == str.size()) {
        return;
    }
    characters.insert(str[i]);
    countAlphabets(str, characters, i+1);
}

int main() {
    string str;cin>>str;
    
    for(int i=0;i<str.size();i++) {
        if(str[i] >= 'A' && str[i] <= 'Z') {
            str[i] += 'a' - 'A';
        }
    }
    set<char> characters;
    
    countAlphabets(str, characters, 0);
    
    cout<<characters.size()<<endl;
}