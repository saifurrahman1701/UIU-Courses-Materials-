#include<iostream>
#include<string>
using namespace std;

bool checkPalindrome(string &str, int i, int j) {
    if(i >= j) return true;
    bool flag;
    if(str[i] == str[j]) {
        flag = checkPalindrome(str, i+1, j-1);
    }
    else {
        flag = false;
    }
    return flag;
}

int main() {
    string str;cin>>str;
    
    for(int i=0;i<str.size();i++) {
        if(str[i] >= 'A' && str[i] <= 'Z') {
            str[i] += 'a' - 'A';
        }
    }
    if(checkPalindrome(str, 0, str.size()-1)) {
        cout<<"YES"<<endl;
    }
    else {
        cout<<"NO"<<endl;
    }
}