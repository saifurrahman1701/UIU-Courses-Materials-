#include<iostream>
#include<vector>
using namespace std;

// This function is calculating number of 1s in a integer. 
int numOf1(int num) {
  int cnt= 0;
  while(num) {
    int reminder = num%2;
    num = num/2;
    if(reminder == 1) {
      cnt++;
    }
  }
  return cnt;
}

// For the same reason as problem1, we are passing (vector<int> &A) instead of (vector<int> A) as a fucntion parameter.
int count_ans(vector<int> &A, int i, int j) {

  //base case
  if(i == j) {
    //calculating number of 1s in A[i]
    int cnt = numOf1(A[i]);
    
    //checking whether the cnt is even or odd
    if(cnt%2 == 0) {
      return 1;
    }
    else {
      return 0;
    }
  }

  // divide part of the algorithm
  int mid = (i+j)/2;
  int left = count_ans(A, i, mid);
  int right = count_ans(A, mid+1, j);
  int total1 = left + right;
  return total1;
}

int main() {

  // taking input: Number of integers
  int n;cin>>n;

  // taking input: All n integers
  vector<int> A;
  for(int i=0;i<n;i++) {
    int x;cin>>x;
    A.push_back(x);
  }

  // computing answer
  int ans = count_ans(A, 0, n-1);

  //printing answer
  cout<<ans<<endl;
}
