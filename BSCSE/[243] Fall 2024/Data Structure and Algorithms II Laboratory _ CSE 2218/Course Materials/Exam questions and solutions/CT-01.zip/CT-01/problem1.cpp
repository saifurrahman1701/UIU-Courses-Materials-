#include<iostream>
#include<string>
using namespace std;

// Here, we are passing str and key by reference. The reason is straightforward: we aim to optimize space complexity. If we used (string str) instead of (string &str), the entire string would be copied and passed as a function parameter with every call to the encrypt() function. By using (string &str), only the memory address of the string's first index is passed, significantly reducing memory usage and improving efficiency.
void encrypt(string &str, string &key, int i, int n, string &encrypted_string) {
  //base case
  if(i == n) {
    return;
  }

  encrypted_string += (str[i] + (key[i]- '0'));
  //recrusive call
  encrypt(str, key, i+1, n, encrypted_string);
}

int main() {
  //input string and public key
  string str, key;
  cin>>str>>key;

  // calculating size of the string
  int n = str.size();

  // this is where the answer will be stored
  string encrypted_string = "";

  //this function will compute the answer
  encrypt(str, key, 0, n, encrypted_string);

  //printing answer
  cout<<encrypted_string<<endl;
}